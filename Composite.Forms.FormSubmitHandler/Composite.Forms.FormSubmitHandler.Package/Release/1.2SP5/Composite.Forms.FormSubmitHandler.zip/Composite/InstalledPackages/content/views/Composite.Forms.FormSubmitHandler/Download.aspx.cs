﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using Composite.Security;
using Composite.ResourceSystem;
using Composite.WebClient;

public partial class Composite_InstalledPackages_content_views_Composite_Forms_FormSubmitHandler_download : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{

		string url = UrlUtils.ResolveAdminUrl(string.Format("InstalledPackages/content/views/Composite.Forms.FormSubmitHandler/GetData.aspx?entityToken={0}", Request["entityToken"]));

		MetaRefresh.Attributes["content"] = string.Format("0; URL={0}", url);

		ContentText.Text = string.Format(@"Are you having problems with the download? Please use this <a href=""{0}"" style=""cursor:pointer;text-decoration:underline"">direct link</a>", url);
	}
}
