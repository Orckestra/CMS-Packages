using System.Collections.Generic;
using System.Xml.Linq;

namespace Layout.Helpers
{
  public static class InlineMethodFunction
  {
    public static IEnumerable<XNode> EmptyNodeList()
    {
      yield break;
    }
  }
}
