using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using Composite.Data;
using Composite.Data.Types;

namespace Composite.Utils
{
  public static class InlineMethodFunction
  {
    public static object NullFunction()
    {
      return null;
    }
  }
}
