﻿using System;
using System.Web.UI;

namespace Composite.Community.QuickPoll
{
	public class QuestionControl : UserControl
	{
		public Guid QuestionId { get; set; }
	}
}