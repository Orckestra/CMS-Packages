using System;
using Composite.Forms;

namespace Composite.Forms.ContactForm
{
	public static class InlineMethodFunction
	{
		public static Type GetEmbedableFieldsTypes()
		{
			 return typeof(ContactFormData);
		}
	}
}
